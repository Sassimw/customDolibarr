# OpenID Connect
Dolibarr module to import [PR#22741](https://github.com/Dolibarr/dolibarr/pull/22741)

For configuration, follow [this issue #22740](https://github.com/Dolibarr/dolibarr/issues/22740).
