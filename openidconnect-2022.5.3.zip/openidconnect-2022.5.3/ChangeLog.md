# Changelog
Le format du fichier est basé sur [Tenez un ChangeLog](http://keepachangelog.com/fr/1.0.0/).

## [Non Distribué]

## [1.0.2] - 26-04-2023
- Add GitLab CI

## [1.0.1] - 20-04-2023
- Fix time zone and dst

## [1.0.0] - 13-04-2023
- Create module

[Non Distribué]: http://git.open-dsi.fr/dolibarr-extension/openidconnect/compare/v1.0.1...HEAD
[1.0.1]: https://git.open-dsi.fr/dolibarr-extension/openidconnect/commits/v1.0.1